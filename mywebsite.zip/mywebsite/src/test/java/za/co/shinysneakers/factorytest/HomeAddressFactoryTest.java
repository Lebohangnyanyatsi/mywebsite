package za.co.shinysneakers.factorytest;

public class HomeAddressFactoryTest {
}
